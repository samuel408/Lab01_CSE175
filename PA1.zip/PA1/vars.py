#
# vars.py
#
# This file contains global variables for route-finding search.
#
# David Noelle - Wed Sep 28 17:45:25 PDT 2022
#

# Number of nodes expanded during a search ...
node_expansion_count = 0
